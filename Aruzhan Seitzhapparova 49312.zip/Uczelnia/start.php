<!DOCTYPE html>
<html>
 <head>
	<?php include './common/headPart.php';?>
 </head>
 <body>	
	<header>
		<?php include './common/headerPart.php';?>		
	</header>
	<article>
		<?php include './articles/articleStart.php';?>
	</article>
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>