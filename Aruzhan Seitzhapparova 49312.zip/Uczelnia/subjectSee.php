<!DOCTYPE html>
<html>
 <head>
	<?php include './common/headPart.php';?>
	<?php include './db/baza.php';?>
	<?php include './db/tableSubjectAdd.php';?>
	<?php include './db/tableSubject.php';?>
 </head>
 <body>	
	<header><?php include './common/headerPart.php';?></header>
	<article><?php include './articles/articleSubjectSee.php';?></article>
	
	<h2>These are the items we have</h2>
	<table>
		<tr>
			<th>subject</th>
			<th>lecturer</th>
			<th>hours</th>			
		</tr>
	<?php
		$i=0;
		while ($i< $num_su) {
			$rs_su->data_seek($i);
			$row = $rs_su->fetch_assoc();
			echo "<tr>";
			echo "<td>".$row["subject_name"]."</td>";
			echo "<td>".$row["subject_lecturer"]."</td>";
			echo "<td>".$row["subject_hours"]."</td>";	
			echo "</tr>";
			$i++;
		}
	?>
	</table>
	
	
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>