<!DOCTYPE html>
<html>
 <head>
	<?php include './common/headPart.php';?>
	<?php include './db/baza.php';?>
	<?php include './db/tableStudent.php';?>
	<?php include './db/tableSubject.php';?>
	<?php include './db/tableQuestion.php';?>
 </head>
 <body>	
	<header>
		<?php include './common/headerPart.php';?>		
	</header>
	<article>
		<?php include './articles/articleExamAdd.php';?>
	</article>
	<form action="examSee.php" method="POST">
	<?php //echo " num_st= ".$num_st; ?>
		<table>
			<tr><th>Student</th><th>Item</th><th>Question</th><th>Answer</th></tr>
			<tr>
				<td><select name="student_id">
					<?php					
						$i=0;					
						while ($i<$num_st){
							$rs_st->data_seek($i);
							$row=$rs_st->fetch_assoc();						
							$student  = "<option value=".$row["student_id"].">";
							$student .= $row["student_surname"]." ";
							$student .= $row["student_name"]." ";
							$student .= $row["studentID"]." ";
							$student .= "</option>";
							echo $student;
							$i++;
						}						
					?>
				</select></td>
				<td><select name="subject_id">
					<?php					
						$i=0;					
						while ($i<$num_su){
							$rs_su->data_seek($i);
							$row=$rs_su->fetch_assoc();						
							$subject  = "<option value=".$row["subject_id"].">";
							$subject .= $row["subject_name"]." ";
							$subject .= $row["subject_lecturer"]." ";							
							$subject .= "</option>";
							echo $subject;
							$i++;
						}						
					?>
				</select></td>
			</tr>
			<tr><td></td><td></td>
				<td><select name="question_id_1">
					<?php					
						$i=0;					
						while ($i<$num_qu){
							$rs_qu->data_seek($i);
							$row=$rs_qu->fetch_assoc();
							$subject  = "<option value=".$row["question_id"].">";
							$subject .= "Question: ".$row["question_question"]." ";
							$subject .= "; Answer(1): ".$row["question_answer_1"]." ";
							$subject .= "; Answer(2): ".$row["question_answer_2"]." ";
							$subject .= "; Answer(3): ".$row["question_answer_3"]." ";
							$subject .= "</option>";
							echo $subject;
							$i++;
						}						
					?>
				</select></td>
				<td><select name="answerNo_1">
					<option value=1>1</option>
					<option value=2>2</option>
					<option value=3>3</option>
				</select></td>
			</tr>
			<tr><td></td><td></td>
				<td><select name="question_id_2">
					<?php					
						$i=0;					
						while ($i<$num_qu){
							$rs_qu->data_seek($i);
							$row=$rs_qu->fetch_assoc();
							$subject  = "<option value=".$row["question_id"].">";
							$subject .= "Question: ".$row["question_question"]." ";
							$subject .= "; Answer(1): ".$row["question_answer_1"]." ";
							$subject .= "; Answer(2): ".$row["question_answer_2"]." ";
							$subject .= "; Answer(3): ".$row["question_answer_3"]." ";
							$subject .= "</option>";
							echo $subject;
							$i++;
						}						
					?>
				</select></td>
				<td><select name="answerNo_2">
					<option value=1>1</option>
					<option value=2>2</option>
					<option value=3>3</option>
				</select></td>
			</tr>
			<tr><td></td><td></td>
				<td><select name="question_id_3">
					<?php					
						$i=0;					
						while ($i<$num_qu){
							$rs_qu->data_seek($i);
							$row=$rs_qu->fetch_assoc();
							$subject  = "<option value=".$row["question_id"].">";
							$subject .= "Question: ".$row["question_question"]." ";
							$subject .= "; Answer(1): ".$row["question_answer_1"]." ";
							$subject .= "; Answer(2): ".$row["question_answer_2"]." ";
							$subject .= "; Answer(3): ".$row["question_answer_3"]." ";
							$subject .= "</option>";
							echo $subject;
							$i++;
						}						
					?>
				</select></td>
				<td><select name="answerNo_3">
					<option value=1>1</option>
					<option value=2>2</option>
					<option value=3>3</option>
				</select></td>
			</tr>
			<tr><td></td><td><input type="submit" value="Add new exam"></td></tr>
		</table>
	</form>
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>