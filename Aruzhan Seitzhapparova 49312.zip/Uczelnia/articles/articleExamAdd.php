<?php
	echo "New exam at University!";
?>