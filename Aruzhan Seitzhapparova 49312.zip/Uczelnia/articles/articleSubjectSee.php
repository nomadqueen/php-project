<?php
	echo "Subjects at our University!";
?>