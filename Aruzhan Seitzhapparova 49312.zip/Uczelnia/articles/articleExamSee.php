<?php
	echo "Exams at our University!";
?>