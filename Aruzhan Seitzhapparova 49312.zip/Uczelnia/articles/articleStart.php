<?php
	echo "Welcome to the University!";
?>