<?php
	echo "Add a new subject at our University!";
?>