<?php
	echo "Add a question to the collection of questions of our University!";
?>