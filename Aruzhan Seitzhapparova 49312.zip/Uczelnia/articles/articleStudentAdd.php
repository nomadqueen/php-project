<?php
	echo "Add a new student of our University!";
?>