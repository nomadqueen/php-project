<!DOCTYPE html>
<html lang="pl">
 <head>
	<?php include './common/headPart.php';?>
	<?php include './db/baza.php';?>
	<?php include './db/tableExamAdd.php';?>
	<?php include './db/tableQuestion.php';?>
	<?php include './db/tableExamAdd2.php';?>
	<?php include './db/tableExam.php';?>	
 </head>
 <body>	
	<header><?php include './common/headerPart.php';?></header>
	<article><?php include './articles/articleExamSee.php';?></article>
	
	<h2>These are the items we have</h2>
	<table>
		<tr>
			<th>Surname</th>
			<th>Name</th>
			<th>item</th>
			<th>lecturer</th>
			<th>question</th>
			<th>rating</th>
		</tr>
	<?php
		$i=0;
		while ($i< $num_ex) {
			$rs_ex->data_seek($i);
			$row = $rs_ex->fetch_assoc();
			echo "<tr>";
			echo "<td>".$row["student_surname"]."</td>";
			echo "<td>".$row["student_name"]."</td>";
			echo "<td>".$row["subject_name"]."</td>";
			echo "<td>".$row["subject_lecturer"]."</td>";
			echo "<td>".$row["question_question"]."</td>";
			//echo "<td>".$row["question_answer_correct"]."</td>";
			echo "<td>".$row["mark"]."</td>";
			echo "</tr>";
			$i++;
		}
	?>
	</table>
	
	
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>