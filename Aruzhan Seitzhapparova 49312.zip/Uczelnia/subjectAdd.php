<!DOCTYPE html>
<html>
 <head>
	<?php include './common/headPart.php';?>
 </head>
 <body>	
	<header>
		<?php include './common/headerPart.php';?>		
	</header>
	<article>
		<?php include './articles/articleSubjectAdd.php';?>
	</article>
	<form action="subjectSee.php" method="POST">
		<table>
			<tr><td></td><td>Enter</td></tr>
			<tr><td>name of the item</td><td><input type="text" name="subject_name"></td></tr>
			<tr><td>the name of the lecturer</td><td><input type="text" name="subject_lecturer"></td></tr>				
			<tr><td>number of hours</td><td><input type="number" name="subject_hours"></td></tr>
			<tr><td></td><td><input type="submit" value="Add new subject"></td></tr>
		</table>
	</form>
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>