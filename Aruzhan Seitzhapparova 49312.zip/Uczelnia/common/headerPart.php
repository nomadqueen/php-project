<?php
	echo "<h1>Welcome to my University</h1>";
	echo "<h3>Science is a source of knowledge<?h3>";
?>