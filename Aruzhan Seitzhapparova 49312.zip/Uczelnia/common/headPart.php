<?php
  echo "<title>Welcome To University</title>";
  echo "<meta charset='UTF-8'>";
  echo "<link rel='stylesheet' href='./style/style.css'>";
?>