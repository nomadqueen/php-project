<?php
	echo '<a href="start.php">Home pagea</a>';
	echo '<nav><ul>';
	echo '<li><a href="studentSee.php">See the students</a></li> ';
	echo '<li><a href="subjectSee.php">View items</a></li> ';
	echo '<li><a href="questionSee.php">See the questions</a></li> ';
	echo '<li><a href="examSee.php">View exams</a></li> ';
	echo '</ul></nav>';	
	echo '<nav><ul>';
	echo '<li><a href="studentAdd.php">Add a student</a></li> ';
	echo '<li><a href="subjectAdd.php">Add items</a></li> ';
	echo '<li><a href="questionAdd.php">Add a question</a></li> ';
	echo '<li><a href="examAdd.php">Add an exam v.1</a></li> ';
	echo '<li><a href="examAdd2.php">Add an exam v.3</a></li> ';
	echo '</ul></nav>';	
?>