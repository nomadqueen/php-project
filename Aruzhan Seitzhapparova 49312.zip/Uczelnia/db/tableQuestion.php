<?php
	$conn = new mysqli($serwer, $username, $password, $database);
	$query = "SELECT * FROM question";
	$rs_qu = $conn->query($query);	
	$conn->close();
	$num_qu = $rs_qu->num_rows;
?>