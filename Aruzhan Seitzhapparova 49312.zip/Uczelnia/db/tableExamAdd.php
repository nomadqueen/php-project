<?php 
	$wpis = TRUE; 
	if (isset($_POST['student_id'] , $_POST['subject_id'] , $_POST['question_id'], $_POST['mark'])){
		$student_id = $_POST['student_id'];
		$subject_id = $_POST['subject_id'];
		$question_id = $_POST['question_id'];
		$mark = $_POST['mark'];
	} else {$wpis = FALSE;}	
	if ($wpis) {
		$conn = new mysqli($serwer, $username, $password, $database);
		$query = "INSERT INTO exam(student_id, subject_id, question_id, mark)";
		$query .= "VALUES('".$student_id."','".$subject_id."','".$question_id."','".$mark."')";
		$conn->query($query);
		$conn->close();
	}
?>