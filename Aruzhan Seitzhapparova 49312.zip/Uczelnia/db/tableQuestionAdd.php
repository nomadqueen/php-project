<?php 
	$wpis = TRUE; 
	if (isset($_POST['question_question'],$_POST['question_answer_1'],$_POST['question_answer_2'],$_POST['question_answer_3'],$_POST['question_answer_correct'])){
		$question_question = $_POST['question_question'];
		$question_answer_1 = $_POST['question_answer_1'];
		$question_answer_2 = $_POST['question_answer_2'];
		$question_answer_3 = $_POST['question_answer_3'];
		$question_answer_correct = $_POST['question_answer_correct'];
	} else {$wpis = FALSE;}	
	if ($wpis) {
		$conn = new mysqli($serwer, $username, $password, $database);
		$query  = "INSERT INTO question(question_question,question_answer_1,";
		$query .= "question_answer_2,question_answer_3,question_answer_correct)";
		$query .= "VALUES('".$question_question."','".$question_answer_1."','";
		$query .= $question_answer_2."','".$question_answer_3."','";
		$query .= $question_answer_correct."')";
		$conn->query($query);
		$conn->close();
	}
?>