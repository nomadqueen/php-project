<?php 
	$wpis = TRUE; 
	if (isset($_POST['subject_name'],$_POST['subject_lecturer'],$_POST['subject_hours'])){
		$subject_name = $_POST['subject_name'];
		$subject_lecturer = $_POST['subject_lecturer'];
		$subject_hours = $_POST['subject_hours'];
	} else {$wpis = FALSE;}	
	if ($wpis) {
		$conn = new mysqli($serwer, $username, $password, $database);
		$query = "INSERT INTO subject(subject_name, subject_lecturer, subject_hours)";
		$query .= "VALUES('".$subject_name."','".$subject_lecturer."','".$subject_hours."')";
		$conn->query($query);
	}
?>