<?php 
	$wpis = TRUE; 
	if (isset($_POST['student_surname'] , $_POST['student_name'] , $_POST['studentID'])){
		$student_surname = $_POST['student_surname'];
		$student_name = $_POST['student_name'];
		$studentID = $_POST['studentID'];
	} else {$wpis = FALSE;}	
	if ($wpis) {
		$conn = new mysqli($serwer, $username, $password, $database);
		$query = "INSERT INTO student(student_name, student_surname, studentID)";
		$query .= "VALUES('".$student_name."','".$student_surname."','".$studentID."')";
		$conn->query($query);
		$conn->close();
	}
?>