<?php
	$conn = new mysqli($serwer, $username, $password, $database);
	$query = "SELECT * FROM student";
	$rs_st = $conn->query($query);	
	$conn->close();
	$num_st = $rs_st->num_rows;
?>