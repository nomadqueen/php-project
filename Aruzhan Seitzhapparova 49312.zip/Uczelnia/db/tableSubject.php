<?php
	$conn = new mysqli($serwer, $username, $password, $database);
	$query = "SELECT * FROM subject";
	$rs_su = $conn->query($query);	
	$conn->close();
	$num_su = $rs_su->num_rows;
?>