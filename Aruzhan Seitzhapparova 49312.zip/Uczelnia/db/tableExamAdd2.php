<?php 
	$wpis = TRUE; 
	if (isset($_POST['student_id'],$_POST['subject_id'],$_POST['question_id_1'],$_POST['question_id_2'],$_POST['question_id_3'],$_POST['answerNo_1'],$_POST['answerNo_2'],$_POST['answerNo_3'])){
		$student_id = $_POST['student_id'];
		$subject_id = $_POST['subject_id'];
		$question_id_1 = $_POST['question_id_1'];
		$question_id = $question_id_1;
		$question_id_2 = $_POST['question_id_2'];
		$question_id_3 = $_POST['question_id_3'];
		$answerNo_1 = $_POST['answerNo_1'];
		$answerNo_2 = $_POST['answerNo_2'];
		$answerNo_3 = $_POST['answerNo_3'];
	} else {$wpis = FALSE;}	
	if ($wpis) {
		$mark = 2;
		
		$conn = new mysqli($serwer, $username, $password, $database);
		$query = "select question_answer_correct from question where question_id='".$question_id_1."'";
		$rs = $conn->query($query);
		//$num = $rs->num_rows;
		//echo "<br>num=".$num."<nr>";
		$rs->data_seek(0);		
		$row=$rs->fetch_assoc();
		$mark += ($row["question_answer_correct"]==$answerNo_1)?1:0;
		//echo "<br>q=".$question_id_1."correct=".$row["question_answer_correct"]." row=".(($row["question_answer_correct"]==$answerNo_1)?1:0)."<br>";
		
		$query = "select question_answer_correct from question where question_id='".$question_id_2."'";
		$rs = $conn->query($query);
		$rs->data_seek(0);
		$row=$rs->fetch_assoc();		
		$mark += ($row["question_answer_correct"]==$answerNo_2)?1:0;
		//echo "<br>q=".$question_id_2."correct=".$row["question_answer_correct"]." row=".(($row["question_answer_correct"]==$answerNo_2)?1:0)."<br>";
		
		$query = "select question_answer_correct from question where question_id='".$question_id_3."'";
		$rs = $conn->query($query);
		$rs->data_seek(0);
		$row=$rs->fetch_assoc();		
		$mark += ($row["question_answer_correct"]==$answerNo_3)?1:0;			
		//echo "<br>q=".$question_id_3."correct=".$row["question_answer_correct"]." row=".(($row["question_answer_correct"]==$answerNo_3)?1:0)."<br>";
		
		$query = "INSERT INTO exam(student_id, subject_id, question_id, mark)";
		$query .= "VALUES('".$student_id."','".$subject_id."','".$question_id."','".$mark."')";
		$conn->query($query);
		$conn->close();
	}
?>