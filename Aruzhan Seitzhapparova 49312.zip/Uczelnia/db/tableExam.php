<?php
	$conn = new mysqli($serwer, $username, $password, $database);
	$query = "SELECT * FROM exam left join (student, subject, question) on (exam.student_id=student.student_id and exam.subject_id=subject.subject_id and exam.question_id=question.question_id)";
/*
	$query = "SELECT * FROM exam left join (student, question) on (exam.student_id=student.student_id  and exam.question_id=question.question_id)";
*/
/*
	$query = "SELECT * FROM exam left join (student, subject, question) on (student.student_id=exam.student_id and subject.subject_id=exam.subject_id and question_question_id=exam.question_id)";
*/
/*
	$query = "SELECT * FROM exam left join (student, subject, question) on (student.student_id=exam.student_id and subject.subject_id=exam.subject_id)";
*/
/*
	$query = "SELECT * FROM exam left join (student, subject) on (exam.student_id=student.student_id and exam.subject_id=subject.subject_id)";
*/
	$rs_ex = $conn->query($query);	
	$conn->close();
	$num_ex = $rs_ex->num_rows;
?>