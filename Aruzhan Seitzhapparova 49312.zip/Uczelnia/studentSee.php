<!DOCTYPE html>
<html>
 <head>
	<?php include './common/headPart.php';?>
	<?php include './db/baza.php';?>
	<?php include './db/tableStudentAdd.php';?>
	<?php include './db/tableStudent.php';?>
 </head>
 <body>	
	<header><?php include './common/headerPart.php';?></header>
	<article><?php include './articles/articleStudentSee.php';?></article>
	
	<h2>These are our students</h2>
	<table>
		<tr>
			<th>surname</th>
			<th>name</th>
			<th>ID</th>			
		</tr>
	<?php
		$i=0;
		while ($i< $num_st) {
			$rs_st->data_seek($i);
			$row = $rs_st->fetch_assoc();
			echo "<tr>";
			echo "<td>".$row["student_surname"]."</td>";
			echo "<td>".$row["student_name"]."</td>";
			echo "<td>".$row["studentID"]."</td>";	
			echo "</tr>";
			$i++;
		}
	?>
	</table>
	
	
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>