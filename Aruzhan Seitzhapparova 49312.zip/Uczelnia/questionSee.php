<!DOCTYPE html>
<html lang="pl">
 <head>
	<?php include './common/headPart.php';?>
	<?php include './db/baza.php';?>
	<?php include './db/tableQuestionAdd.php';?>
	<?php include './db/tableQuestion.php';?>
 </head>
 <body>	
	<header><?php include './common/headerPart.php';?></header>
	<article><?php include './articles/articleQuestionSee.php';?></article>
	
	<h2>These are the items we have</h2>
	<table>
		<tr>
			<th>Question</th>
			<th>Answer 1</th>
			<th>Answer 2</th>
			<th>Answer 3</th>
			<th>Correct</th>
		</tr>
	<?php
		$i=0;
		while ($i< $num_qu) {
			$rs_qu->data_seek($i);
			$row = $rs_qu->fetch_assoc();
			echo "<tr>";
			echo "<td>".$row["question_question"]."</td>";
			echo "<td>".$row["question_answer_1"]."</td>";
			echo "<td>".$row["question_answer_2"]."</td>";
			echo "<td>".$row["question_answer_3"]."</td>";
			echo "<td>".$row["question_answer_correct"]."</td>";
			echo "</tr>";
			$i++;
		}
	?>
	</table>
	
	
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>