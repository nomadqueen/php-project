<!DOCTYPE html>
<html>
 <head>
	<?php include './common/headPart.php';?>
 </head>
 <body>	
	<header>
		<?php include './common/headerPart.php';?>		
	</header>
	<article>
		<?php include './articles/articleQuestionAdd.php';?>
	</article>
	<form action="questionSee.php" method="POST">
		<table>
			<tr><td></td><td>Enter</td></tr>
			<tr><td>question</td><td><input type="text" name="question_question"></td></tr>
			<tr><td>answer 1</td><td><input type="text" name="question_answer_1"></td></tr>			
			<tr><td>answer 2</td><td><input type="text" name="question_answer_2"></td></tr>
			<tr><td>answer 3</td><td><input type="text" name="question_answer_3"></td></tr>
			<tr><td>correct answer</td><td><input type="number" name="question_answer_correct"></td></tr>
			<tr><td></td><td><input type="submit" value="Add new question"></td></tr>
		</table>
	</form>
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>