<!DOCTYPE html>
<html>
 <head>
	<?php include './common/headPart.php';?>
 </head>
 <body>	
	<header>
		<?php include './common/headerPart.php';?>		
	</header>
	<article>
		<?php include './articles/articleStudentAdd.php';?>
	</article>
	<form action="studentSee.php" method="POST">
		<table>
			<tr><td></td><td>Enter</td></tr>
			<tr><td>student's name</td><td><input type="text" name="student_surname"></td></tr>
			<tr><td>student name</td><td><input type="text" name="student_name"></td></tr>				
			<tr><td>ID student</td><td><input type="number" name="studentID"></td></tr>
			<tr><td></td><td><input type="submit" value="Add new student"></td></tr>
		</table>
	</form>
	<footer>
		<?php include 'common/nav.php'; ?>
		<?php include 'common/footerPart.php'; ?>
	</footer>
 </body>
</html>